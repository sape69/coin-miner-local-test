# COIN MINER v5 — production release plan

## Status

The project is now organized for a production deployment, but it is NOT
published or connected to your accounts automatically. The remaining steps
require your own domain, hosting, AdMob account and Google Play Console.

## Server

1. Create a Linux VM/container host.
2. Point `api.example.com` to it.
3. Put HTTPS in front of the nginx proxy (for example with a managed load
   balancer or a certificate/ACME setup).
4. Copy `.env.production.example` to `.env` and replace every secret.
5. Start PostgreSQL + API + proxy with `docker compose -f docker-compose.prod.yml up -d`.
6. Run the Prisma migration against production once.
7. Test `GET /health`.
8. Configure AdMob SSV callback as:
   `https://api.example.com/api/v1/admob/ssv`

Google requires the SSV callback URL to be configured and verified in AdMob.
The server should treat the verified SSV callback as authoritative when the
reward affects the in-app economy.

## Android release

1. Replace the Google test AdMob App ID/ad unit with your production IDs.
2. Set the production API base URL in `apps/mobile/lib/config.dart`.
3. Generate your upload key and keep it outside the repository.
4. Build a release Android App Bundle (`.aab`).
5. Enrol the app in Google Play App Signing.
6. Upload the bundle to an internal testing track before production.
7. Test rewarded ads, SSV delivery, duplicate callbacks and offline behavior.
8. Only then promote to closed/open testing and production.

Google Play uses Play App Signing for distribution of app bundles; keep the
upload key secure and separate from the signing key.

## Economy

For now COIN is an in-app ledger unit. Do NOT promise cash value or withdrawals
until the legal, tax, consumer-protection and applicable virtual-currency /
crypto requirements for the target countries have been reviewed.

## Abuse controls before public launch

- Real authentication instead of demo-login
- IP/device/account rate limiting
- Play Integrity
- Server audit logs
- Database backups and restore drills
- Alerting for abnormal reward volume
- Account suspension/admin tooling
- Privacy consent and policy pages
- Terms of service
- AdMob policy review

## Important SSV note

SSV is designed to protect rewarded-ad callbacks from client spoofing. Google
also notes that SSV callbacks can be delayed. Because COIN affects the app's
economy, this project intentionally waits for server verification before final
crediting instead of trusting the client callback as the source of truth.
