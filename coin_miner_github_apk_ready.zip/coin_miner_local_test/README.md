# COIN MINER — Local Test Edition

This is a standalone Flutter test build. It does NOT require:
- a backend
- PostgreSQL
- an internet connection
- an AdMob account
- SSV

It simulates the rewarded-ad step with a 5-second local test dialog. After the
test ad finishes, +10 COIN is added to a local device balance.

Data is stored with SharedPreferences, so restarting the app keeps the test
balance/history.

## Run on Android

From `apps/mobile`:

```bash
flutter pub get
flutter devices
flutter run
```

For a physical Android device, enable Developer Options and USB debugging.
Android's official documentation recommends testing on a real device before
release; an Android Emulator can also be used.

## Reset

Use the restart icon in the top-right corner to clear the local test balance,
streak and history.

## Important

This build is ONLY a local gameplay test. The simulated ad is not a real
advertisement and does not generate revenue. The production COIN MINER v5
package remains separate and uses the AdMob/SSV architecture.
