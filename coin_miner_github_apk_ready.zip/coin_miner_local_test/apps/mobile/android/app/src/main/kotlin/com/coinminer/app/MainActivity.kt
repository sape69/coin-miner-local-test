package com.coinminer.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
