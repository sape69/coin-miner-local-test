# Android project

This is a minimal Android host project for the Flutter app.

If your installed Flutter version reports generated-project compatibility issues,
run `flutter create .` from `apps/mobile` and keep the Dart files under `lib/`.
