import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CoinMinerLocalApp());

class CoinMinerLocalApp extends StatelessWidget {
  const CoinMinerLocalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'COIN MINER Local Test',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF07090D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7CFF6B),
          brightness: Brightness.dark,
        ),
      ),
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  static const reward = 10;
  static const cooldown = Duration(minutes: 1);

  int balance = 0;
  int streak = 0;
  DateTime? nextMining;
  List<String> history = [];
  Timer? timer;

  Duration get remaining =>
      nextMining == null ? Duration.zero : nextMining!.difference(DateTime.now());

  bool get canMine => nextMining == null || remaining.isNegative;

  @override
  void initState() {
    super.initState();
    _load();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      balance = p.getInt('balance') ?? 0;
      streak = p.getInt('streak') ?? 0;
      final raw = p.getString('nextMining');
      nextMining = raw == null ? null : DateTime.tryParse(raw);
      history = p.getStringList('history') ?? [];
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('balance', balance);
    await p.setInt('streak', streak);
    if (nextMining == null) {
      await p.remove('nextMining');
    } else {
      await p.setString('nextMining', nextMining!.toIso8601String());
    }
    await p.setStringList('history', history);
  }

  String _clock() {
    final d = remaining.isNegative ? Duration.zero : remaining;
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _mine() async {
    if (!canMine) return;

    // Local fake rewarded-ad screen. No ad network and no server are used.
    final watched = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _FakeAdDialog(),
    );

    if (watched != true) return;

    setState(() {
      balance += reward;
      streak += 1;
      nextMining = DateTime.now().add(cooldown);
      history.insert(0, '+$reward COIN • ${DateTime.now().toLocal()}');
      if (history.length > 30) history = history.take(30).toList();
    });
    await _save();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('+10 COIN lisätty paikalliseen testisaldoon!')),
      );
    }
  }

  Future<void> _reset() async {
    setState(() {
      balance = 0;
      streak = 0;
      nextMining = null;
      history.clear();
    });
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('COIN MINER',
            style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: 'Nollaa testidata',
            onPressed: _reset,
            icon: const Icon(Icons.restart_alt_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
        children: [
          _Card(
            child: Column(
              children: [
                const Text('TESTISALDO',
                    style: TextStyle(color: Colors.white54, letterSpacing: 2)),
                const SizedBox(height: 8),
                Text('$balance COIN',
                    style: const TextStyle(
                        fontSize: 40, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _Card(
            child: Column(
              children: [
                const Icon(Icons.bolt_rounded, size: 48),
                const SizedBox(height: 8),
                Text(canMine ? 'PÄIVÄN LOUHINTA' : 'LOUHITTU',
                    style: const TextStyle(
                        fontSize: 19, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(canMine
                    ? 'Testaa louhintaa paikallisesti'
                    : 'Seuraava testilouhinta: ${_clock()}',
                    style: const TextStyle(color: Colors.white60)),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: FilledButton(
                    onPressed: canMine ? _mine : null,
                    child: Text(canMine ? 'LOUHI +10 COIN' : _clock()),
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'TESTITILA: mainos simuloidaan paikallisesti',
                  style: TextStyle(color: Colors.white38, fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _Stat(label: 'PUTKI', value: '$streak pv')),
              const SizedBox(width: 12),
              Expanded(child: _Stat(
                  label: 'SEURAAVA', value: canMine ? 'NYT' : _clock())),
            ],
          ),
          const SizedBox(height: 24),
          const Text('TESTIHISTORIA',
              style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
          const SizedBox(height: 10),
          ...history.map((x) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              dense: true,
              tileColor: const Color(0xFF10151B),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              leading: const CircleAvatar(
                  child: Icon(Icons.bolt_rounded, size: 18)),
              title: Text(x),
            ),
          )),
          if (history.isEmpty)
            const Padding(
              padding: EdgeInsets.all(30),
              child: Center(child: Text('Paina LOUHI aloittaaksesi testin.')),
            ),
        ],
      ),
    );
  }
}

class _FakeAdDialog extends StatefulWidget {
  const _FakeAdDialog();
  @override
  State<_FakeAdDialog> createState() => _FakeAdDialogState();
}

class _FakeAdDialogState extends State<_FakeAdDialog> {
  int seconds = 5;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (seconds <= 1) {
        timer?.cancel();
        setState(() => seconds = 0);
      } else {
        setState(() => seconds--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('TESTIMAINOS'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: 180,
            width: double.infinity,
            decoration: BoxDecoration(
              color: const Color(0xFF181E25),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Center(
              child: Icon(Icons.play_circle_outline_rounded, size: 72),
            ),
          ),
          const SizedBox(height: 16),
          Text(seconds > 0
              ? 'Simuloitu mainos päättyy ${seconds}s kuluttua'
              : 'Mainos katsottu — palkkio voidaan myöntää.'),
        ],
      ),
      actions: [
        TextButton(
          onPressed: seconds == 0 ? () => Navigator.pop(context, true) : null,
          child: const Text('SULJE JA LOUHI'),
        ),
      ],
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      color: const Color(0xFF10151B),
      borderRadius: BorderRadius.circular(28),
      border: Border.all(color: Colors.white10),
    ),
    child: child,
  );
}

class _Stat extends StatelessWidget {
  final String label, value;
  const _Stat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFF10151B),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white10),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(
          color: Colors.white54, fontSize: 10, letterSpacing: 1)),
        const SizedBox(height: 5),
        Text(value, style: const TextStyle(
          fontSize: 17, fontWeight: FontWeight.w800)),
      ],
    ),
  );
}
