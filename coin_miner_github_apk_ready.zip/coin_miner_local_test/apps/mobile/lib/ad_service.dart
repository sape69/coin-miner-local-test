import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdService {
  RewardedAd? _rewardedAd;
  bool _loading = false;

  // Google-provided Android rewarded test ad unit.
  static const String androidTestRewardedUnit =
      'ca-app-pub-3940256099942544/5224354917';

  bool get isReady => _rewardedAd != null;

  void load() {
    if (_loading || _rewardedAd != null) return;
    _loading = true;

    RewardedAd.load(
      adUnitId: androidTestRewardedUnit,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _loading = false;
          _rewardedAd = ad;
        },
        onAdFailedToLoad: (_) {
          _loading = false;
          _rewardedAd = null;
        },
      ),
    );
  }

  Future<bool> show() async {
    final ad = _rewardedAd;
    if (ad == null) {
      load();
      return false;
    }

    _rewardedAd = null;
    var earned = false;

    final done = Future<void>.delayed(const Duration(milliseconds: 1));
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        load();
      },
      onAdFailedToShowFullScreenContent: (ad, _) {
        ad.dispose();
        load();
      },
    );

    ad.show(
      onUserEarnedReward: (_, reward) {
        earned = true;
      },
    );

    await done;
    // The SDK callback runs asynchronously. The caller should wait for the
    // ad overlay to finish via the UI flow; this method is intentionally a
    // small adapter and the app reloads the ad after dismissal.
    await Future<void>.delayed(const Duration(milliseconds: 100));
    return earned;
  }

  void dispose() {
    _rewardedAd?.dispose();
    _rewardedAd = null;
  }
}
