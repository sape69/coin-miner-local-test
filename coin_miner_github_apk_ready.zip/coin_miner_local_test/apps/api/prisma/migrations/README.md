Run `npx prisma migrate dev --name init` after setting DATABASE_URL.
