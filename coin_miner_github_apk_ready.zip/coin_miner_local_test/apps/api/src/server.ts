import "dotenv/config";
import express from "express";
import cors from "cors";
import { createVerify, createPublicKey, KeyObject } from "node:crypto";
import jwt from "jsonwebtoken";
import { PrismaClient, MiningStatus, LedgerType } from "@prisma/client";
import { z } from "zod";

const prisma = new PrismaClient();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = Number(process.env.PORT ?? 3000);
const JWT_SECRET = process.env.JWT_SECRET ?? "dev-secret";
const DAILY_REWARD = BigInt(process.env.DAILY_REWARD ?? "10");
const ADMOB_AD_UNIT_ID = process.env.ADMOB_AD_UNIT_ID ?? "";
const ADMOB_REWARD_ITEM = process.env.ADMOB_REWARD_ITEM ?? "coins";
const ADMOB_SSV_MAX_AGE_SECONDS = Number(process.env.ADMOB_SSV_MAX_AGE_SECONDS ?? "300");
const ADMOB_KEYS_URL =
  process.env.ADMOB_KEYS_URL ??
  "https://www.gstatic.com/admob/reward/verifier-keys.json";

type GoogleKey = { keyId: number; pem: string; base64?: string };
type KeyCache = { expiresAt: number; keys: Map<number, KeyObject> };
let keyCache: KeyCache | null = null;

function sign(userId: string) {
  return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: "30d" });
}

async function auth(req: express.Request, res: express.Response, next: express.NextFunction) {
  try {
    const raw = req.headers.authorization?.replace("Bearer ", "");
    if (!raw) return res.status(401).json({ error: "Missing bearer token" });
    const payload = jwt.verify(raw, JWT_SECRET) as { sub: string };
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user || user.status !== "ACTIVE") return res.status(401).json({ error: "Unauthorized" });
    (req as any).userId = user.id;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

function utcDay(d = new Date()) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}

async function loadGoogleKeys(force = false): Promise<Map<number, KeyObject>> {
  if (!force && keyCache && Date.now() < keyCache.expiresAt) return keyCache.keys;

  const response = await fetch(ADMOB_KEYS_URL);
  if (!response.ok) throw new Error(`AdMob key server returned ${response.status}`);

  const body = await response.json() as { keys?: GoogleKey[] };
  if (!body.keys?.length) throw new Error("AdMob key server returned no keys");

  const keys = new Map<number, KeyObject>();
  for (const item of body.keys) {
    if (item.keyId && item.pem) keys.set(item.keyId, createPublicKey(item.pem));
  }
  if (!keys.size) throw new Error("No usable AdMob public keys");

  // Google recommends not caching verification keys longer than 24 hours.
  keyCache = { keys, expiresAt: Date.now() + 23 * 60 * 60 * 1000 };
  return keys;
}

function verifyAdMobSignature(rawQuery: string, signatureB64Url: string, key: KeyObject): boolean {
  // Google signs the raw query content before &signature=...&key_id=...
  // Do not decode, reorder, or reconstruct the signed content.
  const verifier = createVerify("SHA256");
  verifier.update(rawQuery, "utf8");
  verifier.end();

  const signature = Buffer.from(
    signatureB64Url.replace(/-/g, "+").replace(/_/g, "/"),
    "base64"
  );

  return verifier.verify(key, signature);
}

async function verifyAdMobSsv(req: express.Request) {
  const rawQuery = req.originalUrl.split("?")[1] ?? "";
  const signatureMarker = "&signature=";
  const keyMarker = "&key_id=";
  const signatureIndex = rawQuery.indexOf(signatureMarker);
  if (signatureIndex < 0) throw new Error("Missing signature");
  if (!rawQuery.endsWith("") || rawQuery.indexOf(keyMarker, signatureIndex) < 0) {
    throw new Error("Missing key_id");
  }

  const signedContent = rawQuery.slice(0, signatureIndex);
  const params = new URLSearchParams(rawQuery);
  const signature = params.get("signature");
  const keyIdText = params.get("key_id");
  if (!signature || !keyIdText) throw new Error("Missing signature or key_id");

  const keyId = Number(keyIdText);
  if (!Number.isSafeInteger(keyId)) throw new Error("Invalid key_id");

  let keys = await loadGoogleKeys(false);
  let key = keys.get(keyId);

  // A key rotation can make a cached key list stale. Refresh once on miss.
  if (!key) {
    keys = await loadGoogleKeys(true);
    key = keys.get(keyId);
  }
  if (!key) throw new Error("Unknown AdMob key_id");

  if (!verifyAdMobSignature(signedContent, signature, key)) {
    throw new Error("Invalid AdMob SSV signature");
  }

  const rewardAmount = Number(params.get("reward_amount"));
  const rewardItem = params.get("reward_item") ?? "";
  const transactionId = params.get("transaction_id") ?? "";
  const timestamp = Number(params.get("timestamp"));
  const customData = params.get("custom_data") ?? "";
  const adUnit = params.get("ad_unit") ?? "";

  if (!Number.isFinite(rewardAmount) || rewardAmount <= 0) throw new Error("Invalid reward_amount");
  if (!transactionId) throw new Error("Missing transaction_id");
  if (!timestamp) throw new Error("Missing timestamp");
  if (!customData) throw new Error("Missing custom_data");
  if (!adUnit) throw new Error("Missing ad_unit");

  const ageSeconds = Math.abs(Date.now() - timestamp) / 1000;
  if (ageSeconds > ADMOB_SSV_MAX_AGE_SECONDS) throw new Error("Stale AdMob SSV callback");

  if (ADMOB_AD_UNIT_ID && adUnit !== ADMOB_AD_UNIT_ID) {
    throw new Error("Unexpected ad_unit");
  }
  if (rewardItem !== ADMOB_REWARD_ITEM) throw new Error("Unexpected reward_item");

  return {
    transactionId,
    rewardAmount,
    rewardItem,
    timestamp: new Date(timestamp),
    customData,
    adUnit,
    adNetwork: params.get("ad_network") ?? null,
  };
}

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/api/v1/auth/demo-login", async (req, res) => {
  const parsed = z.object({ email: z.string().email() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid email" });

  const email = parsed.data.email.toLowerCase();
  let user = await prisma.user.findUnique({ where: { email } });
  if (!user) user = await prisma.user.create({ data: { email, wallet: { create: {} } } });
  await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

  res.json({ token: sign(user.id), user: { id: user.id, email: user.email } });
});

app.get("/api/v1/users/me", auth, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: (req as any).userId },
    select: { id: true, email: true, status: true, createdAt: true }
  });
  res.json(user);
});

app.get("/api/v1/wallet", auth, async (req, res) => {
  const wallet = await prisma.wallet.findUnique({ where: { userId: (req as any).userId } });
  res.json({ balance: Number(wallet?.balance ?? 0), currency: "COIN" });
});

app.get("/api/v1/wallet/transactions", auth, async (req, res) => {
  const entries = await prisma.ledgerEntry.findMany({
    where: { userId: (req as any).userId }, orderBy: { createdAt: "desc" }, take: 100
  });
  res.json(entries.map(e => ({
    id: e.id, type: e.type, amount: Number(e.amount),
    description: e.description, createdAt: e.createdAt
  })));
});

app.get("/api/v1/mining/status", auth, async (req, res) => {
  const userId = (req as any).userId;
  const day = utcDay();
  const event = await prisma.miningEvent.findUnique({
    where: { userId_miningDate: { userId, miningDate: day } }
  });
  const streak = await prisma.miningEvent.count({
    where: { userId, status: MiningStatus.COMPLETED }
  });

  res.json({
    canMine: !event,
    reward: Number(DAILY_REWARD),
    streak: Math.min(streak, 7),
    pending: event?.status === MiningStatus.PENDING,
    nextMiningAt: event ? new Date(day.getTime() + 86400000).toISOString() : null
  });
});

app.get("/api/v1/mining/history", auth, async (req, res) => {
  const events = await prisma.miningEvent.findMany({
    where: { userId: (req as any).userId },
    orderBy: { createdAt: "desc" }, take: 30
  });
  res.json(events.map(e => ({
    id: e.id, amount: Number(e.rewardAmount), status: e.status,
    date: e.miningDate, completedAt: e.completedAt
  })));
});

app.post("/api/v1/mining/start", auth, async (req, res) => {
  const userId = (req as any).userId;
  const day = utcDay();

  try {
    const event = await prisma.miningEvent.create({
      data: { userId, rewardAmount: DAILY_REWARD, miningDate: day }
    });
    res.json({ miningEventId: event.id, reward: Number(DAILY_REWARD) });
  } catch (e: any) {
    if (e.code === "P2002") return res.status(409).json({ error: "Already mined today" });
    res.status(500).json({ error: "Unable to start mining" });
  }
});

/*
 * REAL ADMOB SSV ENDPOINT.
 *
 * Configure this exact URL in the AdMob rewarded ad unit:
 * https://YOUR_API_HOST/api/v1/admob/ssv
 *
 * Google sends the signed callback. We:
 * 1) verify Google's ECDSA signature against Google's rotating public key;
 * 2) validate timestamp/ad unit/reward item;
 * 3) use custom_data to locate the pending mining event;
 * 4) use transaction_id as an idempotency key;
 * 5) increment the wallet and write the ledger in one DB transaction.
 */
app.get("/api/v1/admob/ssv", async (req, res) => {
  try {
    const callback = await verifyAdMobSsv(req);

    const miningEventId = callback.customData;
    const existing = await prisma.adReward.findUnique({
      where: { providerRewardId: callback.transactionId }
    });

    // Google retries SSV callbacks. A duplicate transaction is already safely processed.
    if (existing) return res.status(200).send("OK");

    await prisma.$transaction(async tx => {
      const event = await tx.miningEvent.findUnique({
        where: { id: miningEventId }
      });

      if (!event) throw new Error("Unknown mining event");
      if (event.status !== MiningStatus.PENDING) {
        // If another verified callback already finalized it, do not grant again.
        if (event.status === MiningStatus.COMPLETED) return;
        throw new Error("Mining event is not rewardable");
      }

      if (BigInt(callback.rewardAmount) !== event.rewardAmount) {
        throw new Error("Reward amount mismatch");
      }

      await tx.adReward.create({
        data: {
          userId: event.userId,
          provider: "admob",
          providerRewardId: callback.transactionId,
          adUnitId: callback.adUnit,
          amount: event.rewardAmount,
          rewardItem: callback.rewardItem,
          verified: true,
          timestamp: callback.timestamp,
          miningEvent: { connect: { id: event.id } }
        }
      });

      await tx.ledgerEntry.create({
        data: {
          userId: event.userId,
          type: LedgerType.MINING_REWARD,
          amount: event.rewardAmount,
          referenceId: event.id,
          description: "Verified AdMob daily mining reward"
        }
      });

      await tx.wallet.update({
        where: { userId: event.userId },
        data: { balance: { increment: event.rewardAmount } }
      });

      await tx.miningEvent.update({
        where: { id: event.id },
        data: { status: MiningStatus.COMPLETED, completedAt: new Date() }
      });
    });

    return res.status(200).send("OK");
  } catch (e: any) {
    console.error("AdMob SSV rejected:", e?.message ?? e);
    return res.status(403).send("Invalid SSV");
  }
});

// Deliberately no client-side /mining/complete endpoint.
// The server trusts only the verified AdMob SSV callback for final balance credit.

app.listen(PORT, () => console.log(`COIN MINER API v4 running on :${PORT}`));
