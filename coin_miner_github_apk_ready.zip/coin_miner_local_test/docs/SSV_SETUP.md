# AdMob SSV setup

COIN MINER v4 makes the balance update only after a verified AdMob server-side
verification callback.

Google's SSV callback contains `custom_data`, `transaction_id`, `reward_amount`,
`reward_item`, `timestamp`, `signature`, and `key_id`. The callback is signed by
AdMob and the server verifies the signature with Google's rotating public key.
Google documents that keys should not be cached longer than 24 hours.

## 1. Environment

Set in `apps/api/.env`:

```env
ADMOB_AD_UNIT_ID=YOUR_REWARDED_AD_UNIT_ID
ADMOB_REWARD_ITEM=coins
ADMOB_SSV_MAX_AGE_SECONDS=300
ADMOB_KEYS_URL=https://www.gstatic.com/admob/reward/verifier-keys.json
```

## 2. Public callback URL

Deploy the API over HTTPS and configure this callback URL in the AdMob rewarded
ad unit's Server-side verification setting:

`https://YOUR_API_HOST/api/v1/admob/ssv`

The API must be publicly reachable. Do not expose PostgreSQL.

## 3. Reward flow

1. App calls `POST /api/v1/mining/start`.
2. Server creates a pending MiningEvent.
3. App attaches that event UUID as AdMob `custom_data`.
4. User watches the rewarded ad.
5. AdMob calls `/api/v1/admob/ssv`.
6. Server verifies the raw signed query string with Google's public key.
7. Server validates `ad_unit`, `reward_item`, `reward_amount`, timestamp and custom data.
8. `transaction_id` is used as an idempotency key.
9. One DB transaction marks the mining event completed, writes the ledger and increments the wallet.
10. Duplicate Google retries return HTTP 200 without another credit.

## Important

The client `onUserEarnedReward` callback is NOT a trust boundary and does not
credit the wallet. SSV is the authoritative reward path.

Use Google's test ad IDs while developing. Before release, configure your own
AdMob app/ad unit and SSV URL.

Sources:
- Google AdMob SSV: https://developers.google.com/admob/flutter/ssv
- Google Android SSV: https://developers.google.com/admob/android/ssv
