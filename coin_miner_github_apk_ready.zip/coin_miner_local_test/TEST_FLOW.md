# 2-minute test

1. Open the app.
2. Confirm `TESTISALDO` is `0 COIN`.
3. Press `LOUHI +10 COIN`.
4. Wait for the 5-second simulated ad.
5. Press `SULJE JA LOUHI`.
6. Confirm balance becomes `10 COIN`.
7. Confirm the history gets a `+10 COIN` entry.
8. Confirm the button is locked for 1 minute.
9. Restart the app: the local balance should remain.
10. Press the restart icon to reset the test.

This intentionally does not connect to the production API or AdMob.
