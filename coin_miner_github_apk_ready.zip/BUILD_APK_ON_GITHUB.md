# COIN MINER – APK rakennus GitHub Actionsilla

## Puhelimella tehtävä tapa

1. Luo GitHubissa uusi repository, esim. `coin-miner-local-test`.
2. Pura tämän ZIPin sisältö ja lataa projektin tiedostot repositoryyn.
3. Varmista, että repositoryn juuressa näkyy:
   `.github/workflows/build-apk.yml`
4. Tee Commit.
5. GitHubissa avaa **Actions**.
6. Valitse **Build COIN MINER APK**.
7. Paina **Run workflow** (tai odota push-buildin valmistumista).
8. Avaa valmis workflow-ajokerta.
9. Kohdasta **Artifacts** lataa `coin-miner-local-test-apk`.
10. Pura artifact ja saat `app-debug.apk`-tiedoston.
11. Avaa APK Android-puhelimella ja salli tarvittaessa selaimelle/tiedostonhallinnalle sovellusten asentaminen tästä lähteestä.

## Huomio

Tämä on debug-test APK. Se on tarkoitettu oman puhelimen testaukseen, ei Google Play -julkaisuun.

Sovellus on täysin paikallinen:
- ei backendia
- ei PostgreSQL:ää
- ei AdMobia
- simuloitu 5 sekunnin mainos
- +10 COIN paikalliseen saldoon
